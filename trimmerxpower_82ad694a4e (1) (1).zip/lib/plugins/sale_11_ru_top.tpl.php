<link rel="stylesheet" type="text/css" href="shared/plugins/sale11/shopping-banner-style.css">
<div class="shopping-day__banner">
    <div class="shopping-day__wrapper">
        <div class="shopping-day__banner-mobile">
            <div class="shopping-day__title-mobile">Всемирный День Шопинга</div>
            <div class="shopping-day__text-mobile"><span>Распродажа</span></div>
            <div class="shopping-day__enddate-mobile">до 14 ноября</div>
        </div>
        <div class="shopping-day__title">Всемирный День Шопинга</div>
        <div class="shopping-day__startdate">11.11</div>
        <div class="shopping-day__enddate">до 14 ноября</div>
        <div class="shopping-day__text"><span class="shopping-day__text-span">Распродажа</span></div>
        <!-- <div class="shopping-day__close_button">x</div> -->
    </div>
</div>
<script src="shared/plugins/sale11/script.js"></script>
